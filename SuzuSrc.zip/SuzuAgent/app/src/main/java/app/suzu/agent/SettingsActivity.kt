package app.suzu.agent

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.EditTextPreference
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        ThemeUtil.prepare(this)
        super.onCreate(savedInstanceState)
        ThemeUtil.applyOverlay(this)
        setContentView(R.layout.activity_settings)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            findPreference<EditTextPreference>("api_key")?.summaryProvider =
                Preference.SummaryProvider<EditTextPreference> { Prefs.maskedKey() }

            findPreference<Preference>("version")?.summary = versionName()

            findPreference<Preference>("fetch_models")?.setOnPreferenceClickListener {
                fetchModels()
                true
            }

            findPreference<Preference>("test_connection")?.setOnPreferenceClickListener {
                testConnection()
                true
            }

            findPreference<ListPreference>("theme")?.setOnPreferenceChangeListener { _, value ->
                Prefs.theme = value as String
                ThemeUtil.applyNightMode()
                activity?.recreate()
                true
            }

            findPreference<SwitchPreferenceCompat>("black_theme")?.setOnPreferenceChangeListener { _, value ->
                Prefs.blackTheme = value as Boolean
                activity?.recreate()
                true
            }

            findPreference<SwitchPreferenceCompat>("dynamic_color")?.setOnPreferenceChangeListener { _, value ->
                Prefs.dynamicColor = value as Boolean
                activity?.recreate()
                true
            }
        }

        private fun versionName(): String {
            val ctx = context ?: return "1.0"
            return try {
                ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0"
            } catch (e: Exception) {
                "1.0"
            }
        }

        private fun fetchModels() {
            val ctx = context ?: return
            lifecycleScope.launch(Dispatchers.IO) {
                val result = runCatching { OpenAIClient().listModels() }
                withContext(Dispatchers.Main) {
                    result.onSuccess { models ->
                        if (models.isEmpty()) {
                            snack(getString(R.string.models_empty))
                            return@onSuccess
                        }
                        MaterialAlertDialogBuilder(ctx)
                            .setTitle(R.string.select_model)
                            .setItems(models.toTypedArray()) { _, which ->
                                Prefs.model = models[which]
                                findPreference<EditTextPreference>("model")?.text = models[which]
                            }
                            .show()
                    }.onFailure {
                        snack(getString(R.string.test_fail, it.message ?: "unknown"))
                    }
                }
            }
        }

        private fun testConnection() {
            lifecycleScope.launch(Dispatchers.IO) {
                val result = runCatching { OpenAIClient().ping() }
                withContext(Dispatchers.Main) {
                    result.onSuccess { snack(getString(R.string.test_ok, it)) }
                        .onFailure { snack(getString(R.string.test_fail, it.message ?: "unknown")) }
                }
            }
        }

        private fun snack(message: String) {
            activity?.findViewById<android.view.View>(android.R.id.content)?.let {
                Snackbar.make(it, message, Snackbar.LENGTH_LONG).show()
            }
        }
    }
}
