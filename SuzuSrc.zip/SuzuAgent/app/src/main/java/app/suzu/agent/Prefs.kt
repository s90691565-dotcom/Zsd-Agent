package app.suzu.agent

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

object Prefs {

    const val DEFAULT_BASE_URL = "https://api.openai.com/v1"
    const val DEFAULT_MODEL = "gpt-4o-mini"
    const val DEFAULT_TEMPERATURE = 0.7f
    const val DEFAULT_MAX_TOKENS = 2048

    private var sp: SharedPreferences? = null

    fun init(context: Context) {
        if (sp == null) {
            sp = PreferenceManager.getDefaultSharedPreferences(context.applicationContext)
        }
    }

    private fun prefs(): SharedPreferences =
        sp ?: throw IllegalStateException("Prefs.init() must be called first")

    var baseUrl: String
        get() {
            val v = prefs().getString("base_url", DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
            return v.trim().trimEnd('/')
        }
        set(value) = prefs().edit().putString("base_url", value.trim().trimEnd('/')).apply()

    var apiKey: String
        get() = prefs().getString("api_key", "") ?: ""
        set(value) = prefs().edit().putString("api_key", value.trim()).apply()

    var model: String
        get() {
            val v = prefs().getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
            return v.trim()
        }
        set(value) = prefs().edit().putString("model", value.trim()).apply()

    var systemPrompt: String
        get() = prefs().getString("system_prompt", "") ?: ""
        set(value) = prefs().edit().putString("system_prompt", value).apply()

    var temperature: Float
        get() = (prefs().getString("temperature", DEFAULT_TEMPERATURE.toString())
            ?: DEFAULT_TEMPERATURE.toString()).toFloatOrNull() ?: DEFAULT_TEMPERATURE
        set(value) = prefs().edit().putString("temperature", value.toString()).apply()

    var maxTokens: Int
        get() = (prefs().getString("max_tokens", DEFAULT_MAX_TOKENS.toString())
            ?: DEFAULT_MAX_TOKENS.toString()).toIntOrNull() ?: DEFAULT_MAX_TOKENS
        set(value) = prefs().edit().putString("max_tokens", value.toString()).apply()

    var stream: Boolean
        get() = prefs().getBoolean("stream", true)
        set(value) = prefs().edit().putBoolean("stream", value).apply()

    var theme: String
        get() = prefs().getString("theme", "system") ?: "system"
        set(value) = prefs().edit().putString("theme", value).apply()

    var blackTheme: Boolean
        get() = prefs().getBoolean("black_theme", false)
        set(value) = prefs().edit().putBoolean("black_theme", value).apply()

    var dynamicColor: Boolean
        get() = prefs().getBoolean("dynamic_color", false)
        set(value) = prefs().edit().putBoolean("dynamic_color", value).apply()

    // Tools
    var toolTime: Boolean
        get() = prefs().getBoolean("tool_time", true)
        set(value) = prefs().edit().putBoolean("tool_time", value).apply()

    var toolSearch: Boolean
        get() = prefs().getBoolean("tool_search", false)
        set(value) = prefs().edit().putBoolean("tool_search", value).apply()

    var toolFetch: Boolean
        get() = prefs().getBoolean("tool_fetch", true)
        set(value) = prefs().edit().putBoolean("tool_fetch", value).apply()

    var agentMode: Boolean
        get() = prefs().getBoolean("tool_agent", false)
        set(value) = prefs().edit().putBoolean("tool_agent", value).apply()

    fun isConfigured(): Boolean = model.isNotEmpty()

    fun maskedKey(): String {
        val k = apiKey
        if (k.isEmpty()) return "未设置"
        return if (k.length <= 8) "****" else k.take(4) + "****" + k.takeLast(4)
    }
}
