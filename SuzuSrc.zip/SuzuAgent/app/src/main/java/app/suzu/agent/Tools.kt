package app.suzu.agent

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.regex.Pattern

/**
 * Built-in local tools. They are described to the model in OpenAI function-calling format.
 */
object Tools {

    const val CURRENT_TIME = "current_time"
    const val WEB_SEARCH = "web_search"
    const val FETCH_URL = "fetch_url"

    fun enabledIds(): List<String> {
        val list = mutableListOf<String>()
        if (Prefs.toolTime) list.add(CURRENT_TIME)
        if (Prefs.toolSearch) list.add(WEB_SEARCH)
        if (Prefs.toolFetch) list.add(FETCH_URL)
        return list
    }

    fun agentEnabled(): Boolean = Prefs.agentMode && enabledIds().isNotEmpty()

    fun definitions(): JSONArray {
        val arr = JSONArray()
        val enabled = enabledIds()

        if (enabled.contains(CURRENT_TIME)) {
            arr.put(jsonTool(CURRENT_TIME, "获取当前日期、时间与时区", JSONObject().put("type", "object")))
        }
        if (enabled.contains(WEB_SEARCH)) {
            val params = JSONObject()
                .put("type", "object")
                .put(
                    "properties", JSONObject().put(
                        "query", JSONObject().put("type", "string")
                            .put("description", "搜索关键词")
                    )
                )
                .put("required", JSONArray().put("query"))
            arr.put(jsonTool(WEB_SEARCH, "联网搜索，返回标题、链接与摘要", params))
        }
        if (enabled.contains(FETCH_URL)) {
            val params = JSONObject()
                .put("type", "object")
                .put(
                    "properties", JSONObject().put(
                        "url", JSONObject().put("type", "string")
                            .put("description", "要抓取的完整 URL")
                    )
                )
                .put("required", JSONArray().put("url"))
            arr.put(jsonTool(FETCH_URL, "抓取网页正文文本（去除脚本与标签）", params))
        }
        return arr
    }

    private fun jsonTool(name: String, description: String, parameters: JSONObject): JSONObject =
        JSONObject().put("type", "function").put(
            "function", JSONObject()
                .put("name", name)
                .put("description", description)
                .put("parameters", parameters)
        )

    fun run(name: String, arguments: JSONObject): String {
        return try {
            when (name) {
                CURRENT_TIME -> {
                    val now = java.text.SimpleDateFormat(
                        "yyyy-MM-dd HH:mm:ss (EEE) zzz",
                        Locale.getDefault()
                    ).format(java.util.Date())
                    "当前时间：$now"
                }

                WEB_SEARCH -> {
                    val query = arguments.optString("query", "").trim()
                    if (query.isEmpty()) return "缺少 query 参数"
                    val url =
                        "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(query, "UTF-8")
                    val html = httpGet(url)
                    searchToText(html)
                }

                FETCH_URL -> {
                    val url = arguments.optString("url", "").trim()
                    if (url.isEmpty()) return "缺少 url 参数"
                    stripHtml(httpGet(url), 6000)
                }

                else -> "未知工具：$name"
            }
        } catch (e: Exception) {
            "工具执行失败：${e.message}"
        }
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
        )
        conn.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val reader = BufferedReader(InputStreamReader(stream ?: conn.inputStream, Charsets.UTF_8))
            val sb = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                sb.append(line).append('\n')
                if (sb.length > 400000) break
            }
            reader.close()
            if (code !in 200..299) throw java.io.IOException("HTTP $code")
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }

    private fun searchToText(html: String): String {
        val out = StringBuilder()
        val titlePattern =
            Pattern.compile("<a[^>]*class=\"result__a\"[^>]*>([\\s\\S]*?)</a>", Pattern.CASE_INSENSITIVE)
        val snippetPattern =
            Pattern.compile(
                "class=\"result__snippet\"[^>]*>([\\s\\S]*?)</a>",
                Pattern.CASE_INSENSITIVE
            )
        val titles = mutableListOf<String>()
        val snippets = mutableListOf<String>()
        val tm = titlePattern.matcher(html)
        var count = 0
        while (tm.find() && count < 8) {
            titles.add(stripHtml(tm.group(1) ?: "", 200).replace('\n', ' '))
            count++
        }
        val sm = snippetPattern.matcher(html)
        count = 0
        while (sm.find() && count < 8) {
            snippets.add(stripHtml(sm.group(1) ?: "", 300).replace('\n', ' '))
            count++
        }
        if (titles.isEmpty()) {
            return stripHtml(html, 2500)
        }
        val n = minOf(titles.size, maxOf(snippets.size, 1))
        for (i in 0 until n) {
            out.append(i + 1).append(". ").append(titles[i]).append('\n')
            if (i < snippets.size) out.append("   ").append(snippets[i]).append('\n')
        }
        return out.toString().ifBlank { "未获取到搜索结果" }
    }

    private fun stripHtml(html: String, limit: Int): String {
        var text = html
        text = Pattern.compile("<script[\\s\\S]*?</script>", Pattern.CASE_INSENSITIVE)
            .matcher(text).replaceAll(" ")
        text = Pattern.compile("<style[\\s\\S]*?</style>", Pattern.CASE_INSENSITIVE)
            .matcher(text).replaceAll(" ")
        text = Pattern.compile("<[^>]+>").matcher(text).replaceAll(" ")
        text = text.replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
        text = Pattern.compile("[ \\t\\u000B\\u000C\\r]+").matcher(text).replaceAll(" ")
        text = Pattern.compile("\n{3,}").matcher(text).replaceAll("\n\n")
        return text.trim().let { if (it.length > limit) it.substring(0, limit) + "…" else it }
    }
}
