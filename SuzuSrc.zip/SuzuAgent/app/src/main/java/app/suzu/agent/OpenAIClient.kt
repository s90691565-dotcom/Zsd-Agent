package app.suzu.agent

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(
    val role: String,
    var content: String = "",
    val toolCalls: JSONArray? = null,
    val toolCallId: String? = null,
    val name: String? = null
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("role", role)
        if (role == "assistant" && toolCalls != null && toolCalls.length() > 0) {
            o.put("tool_calls", toolCalls)
            if (content.isEmpty()) o.put("content", JSONObject.NULL) else o.put("content", content)
        } else if (role == "tool") {
            o.put("content", content)
            o.put("tool_call_id", toolCallId ?: "")
            if (!name.isNullOrEmpty()) o.put("name", name)
        } else {
            o.put("content", content)
        }
        return o
    }

    fun isUser(): Boolean = role == "user"
}

/**
 * Minimal client for any OpenAI-compatible /chat/completions endpoint.
 * Uses HttpURLConnection only, so no third-party network dependency is needed.
 */
class OpenAIClient {

    @Volatile
    var canceled: Boolean = false

    private fun endpoint(path: String): String {
        var base = Prefs.baseUrl
        if (base.isEmpty()) base = Prefs.DEFAULT_BASE_URL
        return base + path
    }

    private fun open(path: String, method: String): HttpURLConnection {
        val conn = URL(endpoint(path)).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 120000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        val key = Prefs.apiKey
        if (key.isNotEmpty()) conn.setRequestProperty("Authorization", "Bearer $key")
        return conn
    }

    fun buildBody(
        history: List<ChatMessage>,
        stream: Boolean,
        withTools: Boolean
    ): JSONObject {
        val messages = JSONArray()
        val sys = Prefs.systemPrompt.trim()
        if (sys.isNotEmpty()) messages.put(JSONObject().put("role", "system").put("content", sys))
        for (m in history) messages.put(m.toJson())

        val body = JSONObject()
        body.put("model", Prefs.model)
        body.put("messages", messages)
        body.put("temperature", Prefs.temperature.toDouble())
        body.put("max_tokens", Prefs.maxTokens)
        body.put("stream", stream)
        if (withTools) {
            val tools = Tools.definitions()
            if (tools.length() > 0) {
                body.put("tools", tools)
                body.put("tool_choice", "auto")
            }
        }
        return body
    }

    /** Non-streaming request, returns the assistant message object. */
    fun chatSync(history: List<ChatMessage>, withTools: Boolean): JSONObject {
        val body = buildBody(history, stream = false, withTools = withTools)
        val conn = open("/chat/completions", "POST")
        try {
            write(conn, body.toString())
            val code = conn.responseCode
            val text = read(conn, code)
            if (code !in 200..299) throw IOException(parseError(code, text))
            val json = JSONObject(text)
            val choices = json.optJSONArray("choices")
            if (choices == null || choices.length() == 0) throw IOException("接口未返回 choices")
            return choices.getJSONObject(0).optJSONObject("message") ?: JSONObject()
        } finally {
            conn.disconnect()
        }
    }

    /** Streaming (SSE) request. Returns the full accumulated content. */
    fun chatStream(history: List<ChatMessage>, onDelta: (String) -> Unit): String {
        val body = buildBody(history, stream = true, withTools = false)
        val conn = open("/chat/completions", "POST")
        val full = StringBuilder()
        try {
            write(conn, body.toString())
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = read(conn, code)
                throw IOException(parseError(code, err))
            }
            val reader = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
            var line: String?
            while (!canceled && reader.readLine().also { line = it } != null) {
                val l = line ?: continue
                if (!l.startsWith("data:")) continue
                val data = l.substring(5).trim()
                if (data.isEmpty()) continue
                if (data == "[DONE]") break
                val obj = JSONObject(data)
                val delta = obj.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")
                val piece = delta?.optString("content")
                if (!piece.isNullOrEmpty()) {
                    full.append(piece)
                    onDelta(piece)
                }
            }
            reader.close()
        } finally {
            conn.disconnect()
        }
        return full.toString()
    }

    fun listModels(): List<String> {
        val conn = open("/models", "GET")
        try {
            val code = conn.responseCode
            val text = read(conn, code)
            if (code !in 200..299) throw IOException(parseError(code, text))
            val data = JSONObject(text).optJSONArray("data")
            val out = mutableListOf<String>()
            if (data != null) {
                for (i in 0 until data.length()) {
                    val id = data.optJSONObject(i)?.optString("id")
                    if (!id.isNullOrEmpty()) out.add(id)
                }
            }
            return out.sorted()
        } finally {
            conn.disconnect()
        }
    }

    /** Minimal connectivity check. */
    fun ping(): String {
        val models = listModels()
        return if (models.isEmpty()) "连接正常（未返回模型列表）" else "连接正常，可用模型 ${models.size} 个"
    }

    private fun write(conn: HttpURLConnection, payload: String) {
        conn.doOutput = true
        val writer = OutputStreamWriter(conn.outputStream, Charsets.UTF_8)
        writer.write(payload)
        writer.flush()
        writer.close()
    }

    private fun read(conn: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        if (stream == null) return ""
        val reader = BufferedReader(InputStreamReader(stream, Charsets.UTF_8))
        val sb = StringBuilder()
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            sb.append(line)
        }
        reader.close()
        return sb.toString()
    }

    private fun parseError(code: Int, body: String): String {
        return try {
            val msg = JSONObject(body).optJSONObject("error")?.optString("message")
            if (!msg.isNullOrEmpty()) "HTTP $code: $msg" else "HTTP $code: ${body.take(200)}"
        } catch (e: Exception) {
            "HTTP $code: ${body.take(200)}"
        }
    }
}
