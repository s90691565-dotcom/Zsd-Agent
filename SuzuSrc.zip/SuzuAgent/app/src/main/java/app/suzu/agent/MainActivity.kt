package app.suzu.agent

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var statusTitle: TextView
    private lateinit var statusSummary: TextView
    private lateinit var statusAction: MaterialButton
    private var testing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        ThemeUtil.prepare(this)
        super.onCreate(savedInstanceState)
        ThemeUtil.applyOverlay(this)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = ""
        toolbar.setOnMenuItemClickListener {
            if (it.itemId == R.id.action_settings) {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            } else false
        }

        statusTitle = findViewById(R.id.status_title)
        statusSummary = findViewById(R.id.status_summary)
        statusAction = findViewById(R.id.status_action)
        statusAction.setOnClickListener { testConnection() }

        bindCard(
            R.id.card_api,
            R.drawable.ic_endpoint,
            getString(R.string.home_api_title),
            getString(R.string.home_api_summary)
        ) { startActivity(Intent(this, SettingsActivity::class.java)) }

        bindCard(
            R.id.card_chat,
            R.drawable.ic_chat,
            getString(R.string.home_chat_title),
            getString(R.string.home_chat_summary)
        ) { startActivity(Intent(this, ChatActivity::class.java)) }

        bindCard(
            R.id.card_tools,
            R.drawable.ic_tools,
            getString(R.string.home_tools_title),
            getString(R.string.home_tools_summary)
        ) { startActivity(Intent(this, ToolsActivity::class.java)) }

        bindCard(
            R.id.card_appearance,
            R.drawable.ic_palette,
            getString(R.string.home_appearance_title),
            getString(R.string.home_appearance_summary)
        ) { startActivity(Intent(this, SettingsActivity::class.java)) }

        bindCard(
            R.id.card_clear,
            R.drawable.ic_clear,
            getString(R.string.home_clear_title),
            getString(R.string.home_clear_summary)
        ) { clearHistory() }

        bindCard(
            R.id.card_about,
            R.drawable.ic_info,
            getString(R.string.home_about_title),
            getString(R.string.home_about_summary, versionName())
        ) { showAbout() }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val ready = Prefs.isConfigured()
        statusTitle.text =
            if (ready) getString(R.string.home_status_ready) else getString(R.string.home_status_title)
        statusSummary.text = if (ready) {
            "${Prefs.model}\n${hostOf(Prefs.baseUrl)} · Key ${Prefs.maskedKey()}"
        } else {
            getString(R.string.home_status_summary)
        }
    }

    private fun hostOf(url: String): String {
        var s = url
        s = s.replace("https://", "").replace("http://", "")
        return s
    }

    private fun bindCard(id: Int, icon: Int, title: String, summary: String, onClick: () -> Unit) {
        val root = findViewById<View>(id) ?: return
        root.findViewById<ImageView>(R.id.card_icon).setImageResource(icon)
        root.findViewById<TextView>(R.id.card_title).text = title
        root.findViewById<TextView>(R.id.card_summary).text = summary
        root.setOnClickListener { onClick() }
    }

    private fun testConnection() {
        if (testing) return
        if (!Prefs.isConfigured()) {
            Snackbar.make(findViewById(android.R.id.content), R.string.chat_no_api, Snackbar.LENGTH_LONG)
                .show()
            return
        }
        testing = true
        statusAction.isEnabled = false
        statusAction.setText(R.string.testing)
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching { OpenAIClient().ping() }
            withContext(Dispatchers.Main) {
                testing = false
                statusAction.isEnabled = true
                statusAction.setText(R.string.home_status_test)
                val msg = result.fold(
                    onSuccess = { getString(R.string.test_ok, it) },
                    onFailure = { getString(R.string.test_fail, it.message ?: "unknown") }
                )
                Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun clearHistory() {
        val file = File(filesDir, ChatActivity.HISTORY_FILE)
        if (file.exists()) file.delete()
        Snackbar.make(findViewById(android.R.id.content), R.string.chat_cleared, Snackbar.LENGTH_SHORT)
            .show()
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.about_title)
            .setMessage(getString(R.string.about_message))
            .setPositiveButton(R.string.close, null)
            .show()
    }

    private fun versionName(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) {
            "1.0"
        }
    }
}
