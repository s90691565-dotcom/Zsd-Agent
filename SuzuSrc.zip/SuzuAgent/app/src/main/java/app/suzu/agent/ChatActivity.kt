package app.suzu.agent

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ChatActivity : AppCompatActivity() {

    companion object {
        const val HISTORY_FILE = "chat.json"
        private const val MAX_ROUNDS = 6
    }

    private val items = mutableListOf<ChatMessage>()
    private val history = mutableListOf<ChatMessage>()
    private lateinit var adapter: ChatAdapter
    private lateinit var input: TextInputEditText
    private lateinit var send: FloatingActionButton
    private lateinit var recycler: RecyclerView
    private val mainHandler = Handler(Looper.getMainLooper())
    private var client: OpenAIClient? = null
    private var running = false
    private var codeBg = 0x22000000

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        ThemeUtil.prepare(this)
        super.onCreate(savedInstanceState)
        ThemeUtil.applyOverlay(this)
        setContentView(R.layout.activity_chat)

        codeBg = resolveColor(com.google.android.material.R.attr.colorSurfaceContainerHighest)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }
        toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_clear -> {
                    items.clear()
                    history.clear()
                    adapter.notifyDataSetChanged()
                    saveHistory()
                    Snackbar.make(
                        findViewById(android.R.id.content),
                        R.string.chat_cleared,
                        Snackbar.LENGTH_SHORT
                    ).show()
                    true
                }

                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }

                else -> false
            }
        }

        recycler = findViewById(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        adapter = ChatAdapter(items, codeBg) { text -> copyText(text) }
        recycler.adapter = adapter

        input = findViewById(R.id.input)
        send = findViewById(R.id.send)
        send.setOnClickListener {
            if (running) {
                client?.canceled = true
            } else {
                sendMessage()
            }
        }
        input.setOnEditorActionListener { _, _, _ ->
            if (!running) sendMessage()
            true
        }

        loadHistory()
        updateSendButton()
    }

    private fun resolveColor(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    private fun sendMessage() {
        val text = input.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return
        if (!Prefs.isConfigured()) {
            Snackbar.make(findViewById(android.R.id.content), R.string.chat_no_api, Snackbar.LENGTH_LONG)
                .show()
            return
        }
        input.setText("")
        val msg = ChatMessage("user", text)
        items.add(msg)
        history.add(msg)
        adapter.notifyItemInserted(items.size - 1)
        runAgent()
    }

    private fun runAgent() {
        setRunning(true)
        val useAgent = Tools.agentEnabled()
        val useStream = Prefs.stream && !useAgent
        val c = OpenAIClient()
        client = c

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                if (useAgent) {
                    withContext(Dispatchers.Main) { addBot("") }
                    var round = 0
                    while (round < MAX_ROUNDS) {
                        round++
                        val message = c.chatSync(history, withTools = true)
                        val toolCalls = message.optJSONArray("tool_calls")
                        val content = message.optString("content", "")
                        if (toolCalls == null || toolCalls.length() == 0) {
                            withContext(Dispatchers.Main) {
                                setBot(content.ifBlank { "（模型未返回内容）" })
                            }
                            history.add(ChatMessage("assistant", content))
                            break
                        }
                        history.add(ChatMessage("assistant", content, toolCalls = toolCalls))
                        for (i in 0 until toolCalls.length()) {
                            val call = toolCalls.getJSONObject(i)
                            val id = call.optString("id")
                            val fn = call.optJSONObject("function") ?: continue
                            val name = fn.optString("name")
                            val args = runCatching {
                                JSONObject(fn.optString("arguments", "{}"))
                            }.getOrDefault(JSONObject())
                            withContext(Dispatchers.Main) {
                                setBot(getString(R.string.chat_tool_running, name))
                            }
                            val result = Tools.run(name, args)
                            history.add(ChatMessage("tool", result, toolCallId = id, name = name))
                        }
                    }
                    if (round >= MAX_ROUNDS) {
                        withContext(Dispatchers.Main) { appendBot("\n（已达到最大工具调用轮次）") }
                    }
                } else if (useStream) {
                    withContext(Dispatchers.Main) { addBot("") }
                    val full = c.chatStream(history) { piece ->
                        mainHandler.post { appendBot(piece) }
                    }
                    history.add(ChatMessage("assistant", full))
                    if (full.isBlank()) {
                        withContext(Dispatchers.Main) { setBot("（模型未返回内容）") }
                    }
                } else {
                    withContext(Dispatchers.Main) { addBot("") }
                    val message = c.chatSync(history, withTools = false)
                    val content = message.optString("content", "")
                    withContext(Dispatchers.Main) {
                        setBot(content.ifBlank { "（模型未返回内容）" })
                    }
                    history.add(ChatMessage("assistant", content))
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    setBot(getString(R.string.chat_error, e.message ?: "unknown"))
                }
            } finally {
                withContext(Dispatchers.Main) { setRunning(false) }
                saveHistory()
            }
        }
    }

    private fun addBot(text: String) {
        items.add(ChatMessage("assistant", text))
        adapter.notifyItemInserted(items.size - 1)
        scrollToEnd()
    }

    private fun appendBot(piece: String) {
        if (items.isEmpty() || items.last().role != "assistant") {
            addBot(piece)
            return
        }
        items.last().content += piece
        adapter.notifyItemChanged(items.size - 1)
        scrollToEnd()
    }

    private fun setBot(text: String) {
        if (items.isEmpty() || items.last().role != "assistant") {
            addBot(text)
            return
        }
        items.last().content = text
        adapter.notifyItemChanged(items.size - 1)
        scrollToEnd()
    }

    private fun scrollToEnd() {
        if (items.isNotEmpty()) recycler.scrollToPosition(items.size - 1)
    }

    private fun setRunning(value: Boolean) {
        running = value
        updateSendButton()
    }

    private fun updateSendButton() {
        send.setImageResource(if (running) R.drawable.ic_stop else R.drawable.ic_send)
        send.contentDescription = getString(if (running) R.string.chat_stop else R.string.chat_send)
    }

    private fun copyText(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("suzu", text))
        Snackbar.make(findViewById(android.R.id.content), R.string.chat_copy, Snackbar.LENGTH_SHORT).show()
    }

    private fun historyFile() = File(filesDir, HISTORY_FILE)

    private fun saveHistory() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (m in items) {
                    if (m.role == "user" || m.role == "assistant") {
                        arr.put(JSONObject().put("role", m.role).put("content", m.content))
                    }
                }
                historyFile().writeText(arr.toString())
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun loadHistory() {
        try {
            val file = historyFile()
            if (!file.exists()) return
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val role = o.optString("role", "user")
                val content = o.optString("content", "")
                if (content.isEmpty()) continue
                val msg = ChatMessage(role, content)
                items.add(msg)
                if (role == "user" || role == "assistant") history.add(msg)
            }
            adapter.notifyDataSetChanged()
            scrollToEnd()
        } catch (e: Exception) {
            // ignore
        }
    }
}

class ChatAdapter(
    private val items: List<ChatMessage>,
    private val codeBackgroundColor: Int,
    private val onLongClick: (String) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_USER = 0
        private const val TYPE_BOT = 1
    }

    override fun getItemViewType(position: Int): Int =
        if (items[position].isUser()) TYPE_USER else TYPE_BOT

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = if (viewType == TYPE_USER) R.layout.item_message_user else R.layout.item_message_bot
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val text = holder.itemView.findViewById<TextView>(R.id.message_text)
        val message = items[position]
        text.text = Markdown.render(message.content, codeBackgroundColor)
        holder.itemView.setOnLongClickListener {
            onLongClick(message.content)
            true
        }
    }

    override fun getItemCount(): Int = items.size

    private class Holder(view: View) : RecyclerView.ViewHolder(view)
}
