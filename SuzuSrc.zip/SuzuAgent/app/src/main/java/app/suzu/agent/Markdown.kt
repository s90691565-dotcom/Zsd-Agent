package app.suzu.agent

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.BulletSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import java.util.regex.Pattern

/**
 * Very small Markdown renderer: fenced code blocks, inline code, bold and unordered lists.
 * Enough for chat output, and keeps the app free of extra dependencies.
 */
object Markdown {

    private val FENCE = Pattern.compile("```[a-zA-Z0-9_+-]*\\n?([\\s\\S]*?)```")
    private val INLINE_CODE = Pattern.compile("`([^`\\n]+)`")
    private val BOLD = Pattern.compile("\\*\\*([\\s\\S]+?)\\*\\*")

    fun render(source: String, codeBackgroundColor: Int): CharSequence {
        val out = SpannableStringBuilder()
        val m = FENCE.matcher(source)
        var last = 0
        while (m.find()) {
            if (m.start() > last) appendText(out, source.substring(last, m.start()), codeBackgroundColor)
            val code = (m.group(1) ?: "").trimEnd('\n')
            val start = out.length
            out.append(code)
            if (out.length > start) {
                out.setSpan(TypefaceSpan("monospace"), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(RelativeSizeSpan(0.9f), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(BackgroundColorSpan(codeBackgroundColor), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            last = m.end()
        }
        if (last < source.length) appendText(out, source.substring(last), codeBackgroundColor)
        return out
    }

    private fun appendText(out: SpannableStringBuilder, text: String, codeBg: Int) {
        val lines = text.split('\n')
        for (i in lines.indices) {
            val raw = lines[i]
            val bullet = raw.startsWith("- ") || raw.startsWith("* ")
            val line = if (bullet) raw.substring(2) else raw
            val start = out.length
            appendInline(out, line, codeBg)
            if (bullet && out.length > start) {
                out.setSpan(BulletSpan(12), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            if (i != lines.lastIndex) out.append('\n')
        }
    }

    private fun appendInline(out: SpannableStringBuilder, line: String, codeBg: Int) {
        // Split by inline code first, then apply bold inside normal segments.
        val cm = INLINE_CODE.matcher(line)
        var last = 0
        while (cm.find()) {
            if (cm.start() > last) appendBold(out, line.substring(last, cm.start()))
            val s = out.length
            out.append(cm.group(1) ?: "")
            if (out.length > s) {
                out.setSpan(TypefaceSpan("monospace"), s, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                out.setSpan(BackgroundColorSpan(codeBg), s, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            last = cm.end()
        }
        if (last < line.length) appendBold(out, line.substring(last))
    }

    private fun appendBold(out: SpannableStringBuilder, text: String) {
        val bm = BOLD.matcher(text)
        var last = 0
        while (bm.find()) {
            if (bm.start() > last) out.append(text.substring(last, bm.start()))
            val s = out.length
            out.append(bm.group(1) ?: "")
            if (out.length > s) {
                out.setSpan(StyleSpan(Typeface.BOLD), s, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            last = bm.end()
        }
        if (last < text.length) out.append(text.substring(last))
    }
}
