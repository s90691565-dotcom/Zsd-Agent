package app.suzu.agent

import android.app.Activity
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.color.DynamicColors

object ThemeUtil {

    fun applyNightMode() {
        val mode = when (Prefs.theme) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    /** Call before super.onCreate(). */
    fun prepare(activity: Activity) {
        applyNightMode()
        if (Prefs.dynamicColor) {
            DynamicColors.applyToActivityIfAvailable(activity)
        }
    }

    /** Call after super.onCreate(). */
    fun applyOverlay(activity: Activity) {
        val night = (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        if (Prefs.blackTheme && night) {
            activity.theme.applyStyle(R.style.ThemeOverlay_Suzu_Black, true)
        }
    }
}
