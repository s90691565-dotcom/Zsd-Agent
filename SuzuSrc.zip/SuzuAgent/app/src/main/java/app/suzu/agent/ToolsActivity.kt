package app.suzu.agent

import android.os.Bundle
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.materialswitch.MaterialSwitch

class ToolsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        ThemeUtil.prepare(this)
        super.onCreate(savedInstanceState)
        ThemeUtil.applyOverlay(this)
        setContentView(R.layout.activity_tools)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        bind(R.id.switch_time, Prefs.toolTime) { Prefs.toolTime = it }
        bind(R.id.switch_search, Prefs.toolSearch) { Prefs.toolSearch = it }
        bind(R.id.switch_fetch, Prefs.toolFetch) { Prefs.toolFetch = it }
        bind(R.id.switch_agent, Prefs.agentMode) { Prefs.agentMode = it }
    }

    private fun bind(id: Int, initial: Boolean, save: (Boolean) -> Unit) {
        val sw = findViewById<MaterialSwitch>(id)
        sw.isChecked = initial
        sw.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean -> save(checked) }
    }
}
